export interface MarmitHub {
    id: number;
    descricao: string;
    data_food: Date;
    disp_ped: boolean;
    cod_tamanho: string;
    valor_tamanho: number;
}