import { TestBed } from '@angular/core/testing';

import { MarmitHubService } from './marmit-hub.service';

describe('MarmitHubService', () => {
  let service: MarmitHubService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MarmitHubService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
