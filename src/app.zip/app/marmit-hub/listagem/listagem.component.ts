import { Component, OnInit } from '@angular/core';
import { MarmitHub } from '../marmit-hub.model';
import { MarmitHubService } from '../marmit-hub.service';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-listagem',
  imports: [CommonModule, RouterLink],
  templateUrl: './listagem.component.html',
  styleUrls: ['./listagem.component.css']
})
export class ListagemComponent implements OnInit {
  marmithubs: MarmitHub[] = [];

  constructor(private marmithubService: MarmitHubService) { }

  ngOnInit(): void {
    this.carregarMarmit();
  }

  carregarMarmit(): void {
    this.marmithubService.listarMarmitHub().subscribe((res) => {
      this.marmithubs = res;
    });
  }

  excluirMarmita(id: number): void {
    if (confirm('Tem certeza que deseja excluir essa marmita?')) {
      this.marmithubService.deletarMarmitHub(id).subscribe({
        next: () => {
          alert('Marmita excluída com sucesso!');
          this.carregarMarmit();
        },
        error: (erro) => {
          alert('Erro ao excluir marmita.');
          console.error(erro);
        }
      });
    }
  }

}


