import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { MarmitHub } from '../marmit-hub.model';

@Component({
  selector: 'app-edicao',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './edicao.component.html',
  styleUrls: ['./edicao.component.css']
})
export class EdicaoComponent {
  marmithub: MarmitHub = {
    id: 0,
    descricao: '',
    data_food: new Date(),
    disp_ped: false,
    cod_tamanho: '',
    valor_tamanho: 0
  };

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private router: Router
  ) {
    const id = this.route.snapshot.params['id'];
    this.http.get<MarmitHub>(`http://localhost:3000/marmit-hub/${id}`)
      .subscribe(data => this.marmithub = data);
  }

  atualizar() {
    this.http.put(`http://localhost:3000/marmit-hub/${this.marmithub.id}`, this.marmithub)
      .subscribe(() => {
        alert('Marmita atualizada com sucesso!');
        this.router.navigate(['/listagem']);
      });
  }
}
